# Talep Karşılaştırma Uygulaması
Bu klasör web uygulaması dosyalarını içerir.