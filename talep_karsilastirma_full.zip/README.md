# Talep Karşılaştırma - React + Firebase
Bu proje teklif karşılaştırma uygulamasıdır.