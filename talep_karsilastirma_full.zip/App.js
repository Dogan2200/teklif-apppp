// React uygulama başlangıç dosyası
function App() { return <h1>Talep App</h1>; }
export default App;