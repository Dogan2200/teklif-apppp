// React entry point
import App from './App';