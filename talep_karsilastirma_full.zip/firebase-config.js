// Firebase config örneği
export const firebaseConfig = { /* ... */ };